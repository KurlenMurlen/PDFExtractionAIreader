import os
import requests
import json
from pdfminer.high_level import extract_text

INPUT_FOLDER = "entrada"
OUTPUT_FOLDER = "saida"
OUTPUT_CSV = "resultado.csv"

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "mistralai/mistral-7b-instruct:free"
OPENROUTER_TOKEN = "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"  # Replace with your OpenRouter API key

def extrair_texto_pdf(pdf_path):
    return extract_text(pdf_path)

def chamar_ia(texto):
    headers = {
        "Authorization": f"Bearer {OPENROUTER_TOKEN}",
        "Content-Type": "application/json"
    }
    prompt = (
        "Extraia os seguintes campos do texto da nota fiscal e devolva em JSON com as chaves: "
        "TOTAL, VALOR DO ISS, ALIQUOTA(%), BASE DE CÁLCULO(R$), DEDUÇÃO, DESCONTO, QTD., VALOR DO SERVIÇO, "
        "INSS, PIS, COFINS, CSLL, IRFF. "
        "Se algum campo não existir, retorne vazio. "
        "Texto:\n" + texto
    )
    payload = {
        "model": OPENROUTER_MODEL,
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }
    response = requests.post(OPENROUTER_API_URL, headers=headers, json=payload, timeout=120)

    if response.status_code != 200:
        raise Exception(f"Erro HTTP {response.status_code}: {response.text}")
    
    resposta = response.json()
    try:
        content = resposta['choices'][0]['message']['content']
        # Try to extract JSON from the response
        start = content.find('{')
        end = content.rfind('}') + 1
        json_str = content[start:end]
        return json.loads(json_str)
    except Exception as e:
        raise Exception(f"Resposta inesperada da IA: {resposta}")

def main():
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    resultados = []
    arquivos = [f for f in os.listdir(INPUT_FOLDER) if f.lower().endswith(".pdf")]
    for arquivo in arquivos:
        pdf_path = os.path.join(INPUT_FOLDER, arquivo)
        texto = extrair_texto_pdf(pdf_path)
        try:
            campos = chamar_ia(texto)
            campos["ARQUIVO"] = arquivo
            resultados.append(campos)
            print(f"Processado: {arquivo}")
        except Exception as e:
            print(f"Erro ao processar {arquivo}: {e}")

    campos_csv = ["ARQUIVO", "TOTAL", "VALOR DO ISS", "ALIQUOTA(%)", "BASE DE CÁLCULO(R$)", "DEDUÇÃO", "DESCONTO", "QTD.", "VALOR DO SERVIÇO", "INSS", "PIS", "COFINS", "CSLL", "IRFF"]
    if resultados:
        with open(os.path.join(OUTPUT_FOLDER, OUTPUT_CSV), "w", encoding="utf-8") as f:
            f.write(";".join(campos_csv) + "\n")
            for linha in resultados:
                f.write(";".join(str(linha.get(campo, "")) for campo in campos_csv) + "\n")
        print(f"Arquivo CSV salvo em {os.path.join(OUTPUT_FOLDER, OUTPUT_CSV)}")
    else:
        print("Nenhum resultado para salvar.")

if __name__ == "__main__":
    main()